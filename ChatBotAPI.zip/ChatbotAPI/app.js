const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');
const Claims = require('./models/claims');
const axios = require('axios');
const routeOne = express.Router();
const ObjId = require('mongoose').Types.ObjectId;


var app = express();

const port = 3000;
const route = require('./routes/route');

//connect to mongoDB

mongoose.connect('mongodb://localhost:27017/uFirst?replicaSet=mongo-repl', { useNewUrlParser: true });

//mongoose.connect('mongodb://localhost:27017/files', { useNewUrlParser : true });

mongoose.connection.on('connected', () => {
    console.log("Connected to Mongo");
})

mongoose.connection.on('error', (err) => {
    if (err) {
        console.log("Error Connecting to Mongo" + err);
    }
})




const changeStream = Claims.watch();
changeStream.on('change', function (change) {
    console.log(change);
    if (change.operationType == "insert") {
        axios({
            method: 'post',
            url: 'http://ec2-3-86-151-89.compute-1.amazonaws.com:3000/api/CreateClaim',
            data: {

                "$class": "com.dxc.occlaimnetwork.CreateClaim",
                "claimNumber": change.fullDocument.claimNumber,
                "claimAmount": change.fullDocument.claimAmount,
                "approvedAmount": 0,
                "type": change.fullDocument.type,
                "taskDescription": change.fullDocument.summary,
                "policy": "resource:com.dxc.occlaimnetwork.Policy#" + change.fullDocument.policyID,
                "policyHolderID": change.fullDocument.policyHolderID,
                "claimant": "resource:com.dxc.occlaimnetwork.Claimant#" + change.fullDocument.conversation[2].userName

            }
        }).then((res) => {
            console.log(res);
        })
            .catch((error) => {
                console.log(error);
            })


    }
    if (change.operationType == "update" || change.operationType == "replace") {
        var temp;
        Claims.findById(change.documentKey._id).then(function (doc) {
	console.log("*****",change.updateDescription.updatedFields.AdjusterDecision);
            axios.post('http://ec2-3-86-151-89.compute-1.amazonaws.com:3000/api/evidenceUpdate', {
                "$class": "com.dxc.occlaimnetwork.evidenceUpdate",
                "evidenceCollected": true,
                "adjusterApprovalStatus": change.updateDescription.updatedFields.AdjusterDecision,
                "approvedAmount": change.updateDescription.updatedFields.approvedAmount,
                "taskDescription": change.updateDescription.updatedFields.summary,
                "claim": "resource:com.dxc.occlaimnetwork.Claim#" + doc.claimNumber
            })
                .then(function (response) {
                    console.log(response);
                }.bind(this))
                .catch(function (error) {
                    console.log(error)
                });
            });
        
    }

})






app.use(cors());
app.use(bodyParser.urlencoded({
extended:true }));
app.use(bodyParser.json())
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', route);

app.get('/', (req, res) => {
    res.send("Home Page");
})

app.listen(port, () => {
    console.log("Served started");
})
