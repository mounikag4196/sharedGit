const express = require('express');
const router = express.Router();
const Claims = require('../models/claims');
const ObjId = require('mongoose').Types.ObjectId;




router.get('/getAll',(req,res)=>{
    Claims.find((err,claims)=>{
        res.json(claims);
    })
})
 
router.get('/getById/:id',(req,res)=>{
    var query = req.params.id;
    Claims.find({'claimNumber':query},(err,claims)=>{
            if(!err)
                res.json(claims);
                else
                console.log('Error:',JSON.stringify(err,undefined,2));
            })
})

router.post('/update/:id',(req,res)=>{
     const filter = {claimNumber : req.params.id}
console.log(req);
console.log(req.body);
    Claims.findOneAndUpdate(filter, { $set: req.body }, { new: true }, (err, doc) => {
         	if (!err) { 
console.log("Inside update");
console.log(req.body);
res.send(doc); }
         	else { console.log('Error in Claims Update :' + JSON.stringify(err, undefined, 2)); }
         	});

})

router.put('/update/:id',(req,res)=>{
     const filter = {claimNumber : req.params.id}

    Claims.findOneAndUpdate(filter, { $set: req.body }, { new: true }, (err, doc) => {
                if (!err) { res.send(doc); }
                else { console.log('Error in Claims Update :' + JSON.stringify(err, undefined, 2)); }
                });

})

module.exports = router;
