'use strict';

var mongoose = require('mongoose')
, Schema = mongoose.Schema;

var productBacklogSchema = new mongoose.Schema({
	
	title					: { type: String, trim: true },
	description				: { type: String, trim: true },
	material				: { type: String, trim: true},
	raisedBy				: { type: Schema.Types.ObjectId, ref: 'User' },
	raisedDate				: { type: Date, default: Date.now },
	status					: { type: String, enum: ['open','approved', 'implemented', 'rejected'], trim: true },
	remarks					: { type: String, trim: true},
	priority				: { type: String, enum: ['medium', 'high', 'low'], trim: true },
	actionBy				: { type: Schema.Types.ObjectId, ref: 'User' },
	releaseDate				: { type: Date }
	
});

module.exports = mongoose.model('productBacklog', productBacklogSchema);