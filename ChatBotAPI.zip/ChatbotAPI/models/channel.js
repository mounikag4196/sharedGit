'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var channelSchema = new mongoose.Schema({
	name 							: { type: String },
	rule							: { type: String},
	description						: { type: String},
	tags							: [{type:String}],
	status							: {type: String, enum: ['draft', 'active','inactive','closed']},
	moderators						: [{ type: Schema.Types.ObjectId, ref: 'User'}],
	needApproval					: {type: String, enum: ['yes', 'no']},
});

module.exports = mongoose.model('channel', channelSchema);