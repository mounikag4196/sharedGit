var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var policyholdersSchema = new Schema({
  		name		: 			String,
  		dob			: 		 	{ type: Date},
  		gender		: 			String,
  		address1	: 			String,
  		address2 	: 			String,
  		lattitude	: 			Number, 
  		longitude	: 			Number,
  		mobile		: 			Number,
  		age			: 			Number,
      email   : String,
		monthsAsCustomer: 		Number,
		insuredEducationLevel: 	String,
		insuredOccupation: 		String,
		insuredHobbies: 		String,
		insuredRelationship: 	String

});
module.exports = mongoose.model('policyholders', policyholdersSchema);