'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var locationSchema = new mongoose.Schema({

	region 							: { type: String },
	country						: { type: String },
	city						: { type: String },
	facility						: { type: String }
	
	});

module.exports = mongoose.model('location', locationSchema);