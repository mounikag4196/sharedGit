var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var claimsSchema = new Schema({
		policyHolderID		: 			{ type: Schema.Types.ObjectId, ref: 'policyholders' },
  		policyID			: 			{ type: Schema.Types.ObjectId, ref: 'policies' }, 
  		claimAmount 		: 			Number, 
  		claimReason			: 			{type:String,trim:true,lowercase:true,enum:['Fraud','completed','needMoreInformation']},
  		claimedDate			: 		 	{ type: Date},  		
  		status				: 			{ type: String, trim: true,
											enum: ['active', 'open', 'documented', 'reviewed', 'paid'] },
		urgency            	:       	Number,
		summary				:    		String,
		coverage			: 			{ type: String, trim: true, lowercase: true, 
											enum: ['covered', 'unknown'] },
		type				: 			{ type: String, trim: true, lowercase: true, 
											enum: ['fire', 'water', 'hailstorm', 'wind', 'rain', 'snow'] },
		droneAvatar         :       	[{type:String}],
		claimantAvatar      :       	[{type:String}],
		AdjusterAvatar      :       	[{type:String}],
		fraudRating			: 			Number,
		AdjusterDecision     :{type:String,trim:true,lowercase:true,enum:['approved','rejected','pending','onhold']},
		claimStatus          :{type:String,trim:true,lowercase:true,enum:['approved','rejected','pending','onhold']},
		approvedAmount       : Number,
		comment              : String,
		claimNumber			: 			Number,
		licenseNumber		: 			String,
		incidentDate		: 			{ type: Date},
		conversation		: [{
					            userName : String,
					            datetime : { type: Date}, 
					            text : String
					        }]
});
module.exports = mongoose.model('claims', claimsSchema);

