'use strict';

var mongoose = require('mongoose')
, Schema = mongoose.Schema;

var accountSchema = new mongoose.Schema({

	accountName                 	: { type: String },
	logo                       	 	: { type: String },
	description                  	: { type: String },
	status                        	: { type: String }

});

module.exports = mongoose.model('account', accountSchema);