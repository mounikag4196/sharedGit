'use strict';

var mongoose = require('mongoose')
    , Schema = mongoose.Schema;

var skillsSchema = new mongoose.Schema({

        WFM_Skill_ID								: { type: Number },
        WFM_Skill_Name								: { type: String },
        WFM_Skill_Description						: { type: String },
        WFM_Category								: { type: String },
        WFM_Group									: { type: String },
        WFM_Kingdom									: { type: String },
        New_Kingdom									: { type: String },
        New_Category								: { type: String },
        New_Group									: { type: String },
        New_Subgroup								: { type: String },
        WFM_Expanded_Skill_Name_Acronyms			: { type: String },
        WFM_Skill_Level								: { type: String },
        WFM_Major_Level_Skill_Name 					: { type: String },
        WFM_Skill_Developer 						: { type: String },
        WFM_Skill_Open_Source_Status				: { type: String },
        WFM_Skill_Lifecycle_Status					: { type: String },
        Change_Notes								: { type: String },
        GRM_ID 										: { type: Number },
        GRMCategory_OldLowest						: { type: String },
        Skill_GRMOldName							: { type: String },
        Skill_GRMxRef                    		  	: { type: String }

    });

module.exports = mongoose.model('skills', skillsSchema);