'use strict';

var mongoose = require('mongoose')
, Schema = mongoose.Schema;

var userSchema 				= require('./user');
var taskDefinitionSchema		= require('./taskDefinition');

var taskResponsesSchema = new mongoose.Schema({
	
	userID						: { type: Schema.Types.ObjectId, ref: 'User', required: true },
	taskID						: { type: Schema.Types.ObjectId, ref: 'task_definition', required: true },
	dateApplied					: { type: Date, required: true },
	status						: { type: String, trim: true, enum: ['applied', 'assigned', 'unassigned', 'rejected','completed','dropped', 'returned','closed'] },
	taskStarted					: { type: Date },
	taskCompleted				: { type: Date },
	proposedStartDate			: { type: Date },
	proposedEndDate				: { type: Date },
	proposedVolume				: { type: Number },
	lastmodified				: { type: Date },
	manHours					: { type: Number },
	comments                    : { type: String },
	taskWiseCredibility				: {type: Number, default: 0},
	team                        : [{
		member								: { type: Schema.Types.ObjectId, ref: 'User'},
		contribution						: { type: Number, default: 0 }
	}],
	publisherID  					: { type: Schema.Types.ObjectId, ref: 'User'},
	feedbackForPublisher						: [{
		query						: { type: String, trim: true, required: true },
		mode						: { type: String, lowercase: true, trim: true, required:true,
											enum: ['star-rating']},
		answer						: { type: String, trim: true },
		weightage					: { type: Number, trim: true},
		ratings						: {type: Number, default: 0}
	}],
	feedback						: [{
		query						: { type: String, trim: true, required: true },
		mode						: { type: String, lowercase: true, trim: true, required:true,
											enum: ['star-rating']},
		answer						: { type: String, trim: true },
		weightage					: { type: Number, trim: true},
		ratings						: {type: Number, default: 0}
	}],
	taskdroppingComments		: { type: String },
	qowAccept					: { type: Number,default: 0},
	taskCompletionComments		: { type: String },
	taskClosedComments			: { type: String },
	taskRejectionComments		: { type: String },
	taskReturnComments			: { type: String },
	taskClosedQOW				: { type: Number },
	taskClosedDate				: { type: Date }
});


module.exports = mongoose.model('task_response', taskResponsesSchema);