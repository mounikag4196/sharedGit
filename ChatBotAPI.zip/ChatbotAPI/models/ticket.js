'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var ticketSchema = new mongoose.Schema({

	category      			: { type: String, enum: ['suggestions','bug'], trim: true },
	comment					: { type: String, trim: true },
	material				: { type: String, trim: true},
	raisedBy				: { type: Schema.Types.ObjectId, ref: 'User' },
	raisedDate				: { type: Date, default: Date.now },
	status					: { type: String, enum: ['open','considered', 'inprogress', 'resolved', 'rejected','deleted', 'new', 'notapproved'], trim: true },
	remarks					: { type: String, trim: true}
});

module.exports = mongoose.model('ticket', ticketSchema);