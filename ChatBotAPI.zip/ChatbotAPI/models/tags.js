'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var tagSchema = new mongoose.Schema({
	name 							: { type: String },
	description						: { type: String }	
});

module.exports = mongoose.model('tag', tagSchema);