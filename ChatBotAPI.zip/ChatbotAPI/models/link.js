'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var linkRefSchema = new mongoose.Schema({

	refDoc						: { type: String },

	linkList					:[{				
			linkDesc				: { type: String },
			link 					: { type: String }
		}]
	});

module.exports = mongoose.model('link_ref', linkRefSchema);