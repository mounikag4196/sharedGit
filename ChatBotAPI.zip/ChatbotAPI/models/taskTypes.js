'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var feedbackDefSchema	= require('./feedbackDef');

var taskTypesSchema = new mongoose.Schema({

	title						: { type: String, trim: true, required: true },
	description					: { type: String, trim: true, required: true },
	feedbackTmpl				: { type: Schema.Types.ObjectId, ref: 'feedbackdefs', required: true },

	scoringFactor				: { type: Number, trim: true, required: true },
	status						: { type: String, trim: true, enum: ['active', 'inactive']}

	});

module.exports = mongoose.model('task_types', taskTypesSchema);