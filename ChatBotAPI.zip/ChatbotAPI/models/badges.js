'use strict';

var mongoose = require('mongoose')
, Schema = mongoose.Schema;

var badgeSchema = new mongoose.Schema({

	badgeName                 	: { type: String },
	logo                       	 	: { type: String },
});

module.exports = mongoose.model('badges', badgeSchema);