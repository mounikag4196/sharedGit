
var mongoose = require('mongoose')
	, Schema = mongoose.Schema;


var demo = new mongoose.Schema({

	 name:String,
 infile: {type:Schema.Types.Mixed}
	
	});

module.exports = mongoose.model('demo', demo);