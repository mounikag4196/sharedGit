'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var offeringsSchema = new mongoose.Schema({

	title						: { type: String, trim: true, required: true },
	description					: { type: String, trim: true, required: true },
	status						: { type: String, trim: true, required: true, enum: ['active', 'inactive']}

	});

module.exports = mongoose.model('offerings', offeringsSchema);