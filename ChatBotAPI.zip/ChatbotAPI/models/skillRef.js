'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var skillRefSchema = new mongoose.Schema({

	refDoc						: { type: String },
	skillList					:[{				
		title						: { type: String },
		experience 					: { type: Number },
		expertise					: { type: String, enum: ['Basic', 'Expert', 'Professional']}
	}]
	});

module.exports = mongoose.model('skill_ref', skillRefSchema);