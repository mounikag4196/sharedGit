'use strict';

var mongoose = require('mongoose')
, Schema = mongoose.Schema;


var notificationsSchema = new mongoose.Schema({
	// notify:[{/
		notifyMessage					: { 
			title						: { type: String },
			des 						: { type: String },
			// avatar           			: { type: String }
		},
		date							:{ type: Date, default: Date.now },
		notifier						: {  type: Schema.Types.ObjectId, ref: 'User' },
		recipient						: [{
			id							: {  type: Schema.Types.ObjectId, ref: 'User' },
			status						: {type:String,trim:true,enum:['read','unread']}
		}]
	// }]
});

module.exports = mongoose.model('notification_tracker', notificationsSchema);