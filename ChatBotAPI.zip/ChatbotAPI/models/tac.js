'use strict';

var mongoose = require('mongoose')
	, Schema = mongoose.Schema;

var tacSchema = new mongoose.Schema({

	title						: { type: String, trim: true },
	description					: { type: String, trim: true },
	material					: { type: String, trim: true, required: true }
});

module.exports = mongoose.model('tacs', tacSchema);