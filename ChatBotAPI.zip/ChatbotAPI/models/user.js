var path            = require('path');
var mongoose        = require('mongoose'), Schema = mongoose.Schema;
var bcrypt          = require('bcrypt-nodejs');
var jwt             = require('jwt-simple');
var constants       = require('../scripts/constants');
var config          = require(path.join(constants.paths.config, '/config'));
var secure          = require(path.join(constants.paths.scripts, '/secure'));
var groupSchema     = require('./group');

var Token = mongoose.Schema({
    token           : {type: String},
    dateCreated     : {type: Date, default: Date.now},
});

Token.statics.hasExpired= function(created) {
    var now = new Date();
    var diff = (now.getTime() - created);
    return diff > config.get('auth.ttl');
};

var TokenModel = mongoose.model('Token', Token);

// define the schema for our user model
var userSchema = mongoose.Schema({
    name             : {
      prefix         : String,
      first          : String,
      middle         : String,
      last           : String,
      suffix         : String
    },
    email            : String,
    avatar           : String,
    summary          : String,
    jobTitle         : String,
    location         :String,
    organization     : { type: String, trim: true },
    legacyOrg        : {type: String, enum: ['CSC','HPE', 'Xchanging', 'Others'], trim: true },
    association      : {type: String, enum: ['employee','freelancer', 'student'], trim: true },
    socialProfile    : [{
      handle         : String,
      network        : String
    }],
    contactNo        : [{
      contactNumber         : String,
      contactType           : String
    }],
    stats            : {
      dateCreated    : Date,
      dateLastLogin  : Date
    },
    preferences      : {
      language       : String
    },
    local            : {
        email        : String,
        password     : String
    },
    facebook         : {
        id           : String,
        token        : String,
        email        : String,
        name         : String
    },
    twitter          : {
        id           : String,
        token        : String,
        displayName  : String,
        username     : String
    },
    google           : {
        id           : String,
        token        : String,
        email        : String,
        name         : String
    },
    token            : {type: Object},
    status           : {type: String, default: 'Active'},
    memberOf         : [{ type: Schema.Types.ObjectId, ref: 'group' }],
    attachment       : { type: String, trim: true },
    region           : { type: String },
    country          : { type: String },
    city             : { type: String },
    facility         : { type: String },
    experience       : {type: Number},
    credibility      : {type: Number, default: 0},
    offerings        : {type: Schema.Types.ObjectId, ref: 'offerings'},
    key              :{type:String},
    chnlSubscription :[{ type: Schema.Types.ObjectId, ref: 'channel'}],
    account         : [{ type: Schema.Types.ObjectId, ref: 'account' }],
    badges         : [{ type: Schema.Types.ObjectId, ref: 'badges' }],
    managerInfo     : {
      shortId       : String,
      email         : String
    },
    securityProfiling: [{
      question : String,
      answer : String
    }],
    resetPasswordToken: String,
    resetPasswordExpires: Date,
    chnlMod: [{
    channelId             : { type: Schema.Types.ObjectId, ref: 'channel'},
    isModerator           :  String,
    needApproval          : {type: String, enum: ['yes', 'no']}
    }],
    productTourVersion: String,
    createdOn: { type: Date, default: Date.now },
    socialNetworkProfile : {
      blogsite       : String,
      personalwebsite: String,
      handle         : String,
      network        : String,
      facebookpage   : String,
      linkedinpage   : String,
      googlepage     : String      
    },
    freelancer: {
      interests      : String
    },
    student : {
      institute      : String,
      course         : String,
      coordinator    : String,
      year           : String
    },
    termsandCond     : String,
    empLevel         : String,
    functions        : {type: String, enum: ['build','sell', 'deliver', 'globalfunctions'], trim: true },
    loggedinCount    : {type:Number,default : 0}
});

// Execute before each user.save() call
userSchema.pre('save', function(callback) {
    var user = this;

    this.token = genToken();
    callback();
});

userSchema.post('init', function(doc) {
  if(doc.avatar === undefined){
    doc.avatar = "/public/assets/g/imgs/avatar.jpg";
  }
  doc.set('groups', secure.getGroups(doc),  { strict: false });
});

userSchema.post('find', function(result) {
  // console.log('find() returned ' + JSON.stringify(result));
  console.log('find() took ' + (Date.now() - this.start) + ' millis');
});

// generating a hash
userSchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
userSchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.local.password);
};

// private method
function genToken() {
  var expires = expiresIn(config.get('auth.expires'));
  var token = jwt.encode({
    exp: expires
  }, config.get('auth.secret'));

  return {
    token: token,
    dateCreated: new Date()
  };
}

function expiresIn(numDays) {
  var dateObj = new Date();
  return dateObj.setDate(dateObj.getDate() + numDays);
}

// create the model for users and expose it to our app
module.exports = mongoose.model('User', userSchema);
module.exports.Token = TokenModel;
