var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var policySchema = new Schema({
  		policyType			: 			String,
  		startDate			: 		 	{ type: Date},
  		endDate				: 			{ type: Date},
  		premiumAmount		: 			Number,
  		coverageAmount 		: 			Number,
  		policyHolderID		: 			{ type: Schema.Types.ObjectId, ref: 'policyholders' }, 
  		status				: 			{ type: String, trim: true, lowercase: true, 
								enum: ['active', 'inactive'] },
  		autoMake			: 			String,
  		autoModel			: 			String,
  		autoYear			: 			Number,
      propLocation      :       String,
	  vehicleNumber :       String,
	  zipcode       :       String
});
module.exports = mongoose.model('policies', policySchema);
